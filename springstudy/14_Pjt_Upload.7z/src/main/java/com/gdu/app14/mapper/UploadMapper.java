package com.gdu.app14.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UploadMapper {

}
