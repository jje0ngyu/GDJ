package com.gdu.app14.service;

public interface UploadService {

}
