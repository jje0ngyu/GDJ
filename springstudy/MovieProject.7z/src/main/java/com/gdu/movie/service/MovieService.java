package com.gdu.movie.service;

public interface MovieService {
	
}
