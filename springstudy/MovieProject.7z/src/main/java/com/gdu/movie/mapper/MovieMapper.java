package com.gdu.movie.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MovieMapper {
	
}
